import java.util.*;//RYan FArrar


public class LinkedCounter implements CountInterface{
	public int Radix;
	public Node front;
	public int size;
	//
	public LinkedCounter(int rad){
		front = new Node(rad);
		Radix = rad;
		size = 0;

	}

	public class Node{//Node class w nes info
		private int count;
		private Node next;		
				public Node(int s){
					Radix = s;
					next = null;
					count = 0;		
				}
	}
	
	
	public void setRadix(int rad){
		int x = getDecimalInt();
		Radix=rad;
		//Make USre to run reset after taking dec int val
		reset();
		int p = 0;
		while(p<x){
		increment();
		p++;	
		}
	}
	public void reset(){
		front.next=null;
		front.count=0;
	}
	public void increment(){
		int i =1;
		boolean done = false;
		Node curr = front;
		while (!done){//first STart
			curr.count++;
			while(curr.count==Radix){//second start
				if(curr.next==null){
					curr.next= new Node(Radix);
				}
				curr.count=0;
				curr=curr.next;
				curr.count++;
				
			}
		done = true;
	}
		
	
	}//end of inc
	public int digits(){
		Node curr = front;
		int i = 1;
		while(curr.next!=null){//simple run thro all
			curr=curr.next;
			i++;
		}
	    return i;			
	}
	
	public int getDecimalInt(){
		Node curr = front;
		int sum = 0;
		int i = 0;
		int p = 0;
		do{
			int Num = curr.count;
			while(i>p){//run thu all, sim code as Alist, 
			Num = Num*Radix;
	        p++;
			}
			p=0;
			i++;
			curr=curr.next;
			sum = sum+Num;
					
		}while(curr!=null);

		return sum;
	}
	
	public boolean equals(CountInterface arg){
		if(getDecimalInt() == arg.getDecimalInt()) {
			return true;
		}
		return false;
	}
	public String toString(){
	
		StringBuilder SB = new StringBuilder();
		
		Node curr = front;
		int B = digits();
		int [] MyArray = new int[B];
		int a = 0;
		while(curr!=null){//here d
			MyArray[a] = curr.count;
			curr = curr.next;
			a++;
		}
		
		for(int i = digits()-1; i>=0; i--){
		    SB.append(MyArray[i]);
			//re-llok later!!!!
		}
		SB.append(" R"+Radix+"-L");
		return SB.toString();
		
	}
	
	
	
	
	private Node getNodeAt(int loc)//HELPER 
	{
		if (loc >= 0 && loc < size)
		{
			Node curr = front;
			for (int i = 0; i < loc; i++)
				curr = curr.next;
			return curr;
		}
		return null;
	}
	
	
	
	
	
}//End of A4class