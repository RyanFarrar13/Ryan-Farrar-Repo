//RYan FArrar
import java.util.*;




public class ArrayCounter implements CountInterface{
	public int Radix;
	public int [] MyArray;
	public ArrayCounter(int rad, int digs){
		MyArray = new int[digs];
		setRadix(rad);		
		
		
		}
	
	
	public void setRadix(int rad){
		int x = getDecimalInt();
		Radix=rad;
		//NEDD TO FINISH GET DECIMAL INT FIRST.....

		reset();
		int p = 0;
		while(p<x){
		increment();
		p++;	
		}
		
		
	}
	
	public void increment(){
		boolean done = false;
		boolean rip = false;
		int loc = 0;
	
		while (!done){
			MyArray[loc]++;
			if (MyArray[loc] == Radix){
				
			   while(!rip){
				   
				   MyArray[loc]=0;
				   loc++;
				    MyArray[loc]++;
				   if(MyArray.length-1==loc && MyArray[loc]==Radix-1){//From here new array if full
					   int ALen = MyArray.length*2;
				int [] NewArray = new int[ALen];
			    int ii =0;
				while(ii<MyArray.length){
					NewArray[ii] = MyArray[ii];
					ii++;
				}
				MyArray = NewArray;
					   }//TIll hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
				  
				   if(MyArray[loc]==Radix){
					   
				   }
				   if(MyArray[loc]!=Radix){
					   rip=true;
				   }   
			   }
			}
			done = true;	
		}
		
		
	//System.out.println(" ORIGINAL VAL " + MyArray[0] + MyArray[1] + MyArray[2] );
	}//END OF INCREMENT
	
	public void reset(){
			
		int x = 0;
		while(x<MyArray.length){
			MyArray[x]=0;
			x++;
	}
	}
	
	public int getDecimalInt(){
		
		int i=0;
		int a=1;
		int p=0;
		int sum=0;
		while(i<MyArray.length){
			int Num = MyArray[i];
			while(i>p){
			Num = Num*Radix;
	        p++;
			}
			p=0;
			i++;
			sum = sum + Num;//almost rec
		}
		
		return sum;
	}
	
	public boolean equals(CountInterface arg){	
		if(getDecimalInt() == arg.getDecimalInt()) {
			return true;//same as L list
		}
		return false;
	}
	
	public String toString(){
		StringBuilder SB = new StringBuilder();
		//hereeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
		int V = digits()-1;		
		int i = V;
		int ii = 0;
		while(i>=ii){
			SB.append(MyArray[i]);
			i--;
		}
		SB.append(" R"+Radix+"-A");
    return SB.toString();
	}
	
	public int digits(){
		int i=MyArray.length-1;
		int ii = 0;
		while(i>=ii && MyArray[i]==0){
			i--;
		}
	i++;
	if(i<=0){
			i++;
			}
		return i;
	}
	
	
	
	
	
	
	
	
	
	
}//End of A4class