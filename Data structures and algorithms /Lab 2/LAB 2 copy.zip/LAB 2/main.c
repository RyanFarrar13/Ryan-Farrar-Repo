/*main.c fully impleneted by Ryan Farrar for class 1566*/
#include <stdio.h>
#include "myLib.h"

int main(void) {
    vec4 v1 = {1.0, 2.0, 3.0, 4.0};//does limit printing to three digits 1.222
    vec4 v2 = {5.0, 6.0, 7.0, 8.0};
    float s = 3.0f;
    mat4 m1 = (mat4){ { 1, -5,  9, 13},   { 2,  6, -10, 14},   { 3,  7, 11, 15},     { 4,  8, 12, -16}   };
    mat4 m2 = (mat4){ { 4,  8, 12, 16},    { 3,  7, 11, 15},      { 2,  6, 10, 14},      { 1,  5,  9, 13}       };

    //tests
    print_v4(Scalar_Vector_Multiplication(v1, s));
    print_v4(Vector_Vector_Addition(v1, v2));
    print_v4(Vector_Vector_Subtraction(v1, v2));
    printf("%.6f\n", Magnitude_Of_Vector(v1));
    print_v4(Normalize_Vector(v1));
    printf("%.6f\n", Dot_Product(v1, v2));
    print_v4(Cross_Product(v1, v2));
    print_mat4(Scalar_Matrix_Multiplication(m1, s));
    print_mat4(Matrix_Matrix_Addition(m1, m2));
    print_mat4(Matrix_Matrix_Subtraction(m1, m2));
    print_mat4(Matrix_Matrix_Multiplication(m1, m2));
    mat4 inv;
    if (Matrix_Inverse(m1, &inv)) {
    print_mat4(inv);
    } else {
    printf("(no inverse \n");
    }
    print_mat4(Transpose_Matrix(m1));
    print_v4(Matrix_Vector_Multiplication(m1, v1));
}
