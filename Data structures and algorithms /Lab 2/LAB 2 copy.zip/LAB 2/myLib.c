/*myLib.c fully impleneted by Ryan Farrar for class 1566*/
/*outside of print_v4 lmao*/
#include "myLib.h"
#include <stdio.h>
#include <math.h>
//---------------------------- VECTOR FUNCTIONS
void print_v4(vec4 v) {
    printf("[ %7.3f %7.3f %7.3f %7.3f ]\n", v.x, v.y, v.z, v.w);
}

vec4 Scalar_Vector_Multiplication(vec4 V, float S){
    vec4 result;
    result.x = S * V.x;
    result.y = S * V.y;
    result.z = S * V.z;
    result.w = S * V.w;
    return result;
}

vec4 Vector_Vector_Addition(vec4 A, vec4 B){
    vec4 result;
    result.x = A.x + B.x;
    result.y = A.y + B.y;
    result.z = A.z + B.z;
    result.w = A.w + B.w;
    return result;
}

vec4 Vector_Vector_Subtraction(vec4 A, vec4 B){
    vec4 result;
    result.x = A.x - B.x;
    result.y = A.y - B.y;
    result.z = A.z - B.z;
    result.w = A.w - B.w;
    return result;
}

float Magnitude_Of_Vector(vec4 V){
    return sqrt(V.x * V.x + V.y * V.y + V.z * V.z + V.w * V.w);
}

vec4 Normalize_Vector(vec4 V){
    float Magnitude = Magnitude_Of_Vector(V);
    if (Magnitude < 0.0000001){return (vec4){0,0,0,0};}//avoid dividing by zero no crash
    return Scalar_Vector_Multiplication(V, 1.0f / Magnitude);//the f stands for float, float over float = float
}

float Dot_Product(vec4 A, vec4 B){
    float fin = A.x * B.x + A.y * B.y + A.z * B.z + A.w * B.w;
    return fin;
}

vec4 Cross_Product(vec4 A, vec4 B){
    vec4 result;
    result.x = A.y * B.z - A.z * B.y;
    result.y = A.z * B.x - A.x * B.z;
    result.z = A.x * B.y - A.y * B.x;
    result.w = 0; // Cross product is not defined for the w component
    return result;
}
//---------------------------- MATRIX FUNCTIONS
/*C normally uses row major order, but in OpenGL we use column major order. */
//example matrix declaration: mat4 m = {{1,5,9,13},{2,6,10,14},{3,7,11,15},{4,8,12,16}};
void print_mat4(mat4 v) {
    printf("this print is column major order\n");
    printf("[ %7.3f %7.3f %7.3f %7.3f ]\n", v.x.x, v.y.x, v.z.x, v.w.x);
    printf("[ %7.3f %7.3f %7.3f %7.3f ]\n", v.x.y, v.y.y, v.z.y, v.w.y);
    printf("[ %7.3f %7.3f %7.3f %7.3f ]\n", v.x.z, v.y.z, v.z.z, v.w.z);
    printf("[ %7.3f %7.3f %7.3f %7.3f ]\n", v.x.w, v.y.w, v.z.w, v.w.w);  
}

mat4 Scalar_Matrix_Multiplication(mat4 M, float S){
    mat4 result;
    result.x = Scalar_Vector_Multiplication(M.x, S);
    result.y = Scalar_Vector_Multiplication(M.y, S);
    result.z = Scalar_Vector_Multiplication(M.z, S);
    result.w = Scalar_Vector_Multiplication(M.w, S);
    return result;
}

mat4 Matrix_Matrix_Addition(mat4 A, mat4 B){
    mat4 result;
    result.x = Vector_Vector_Addition(A.x, B.x);
    result.y = Vector_Vector_Addition(A.y, B.y);
    result.z = Vector_Vector_Addition(A.z, B.z);
    result.w = Vector_Vector_Addition(A.w, B.w);
    return result;
}

mat4 Matrix_Matrix_Subtraction(mat4 A, mat4 B){
    mat4 result;
    result.x = Vector_Vector_Subtraction(A.x, B.x);
    result.y = Vector_Vector_Subtraction(A.y, B.y);
    result.z = Vector_Vector_Subtraction(A.z, B.z);
    result.w = Vector_Vector_Subtraction(A.w, B.w);
    return result;
}

mat4 Matrix_Matrix_Multiplication(mat4 A, mat4 B){//manually doing bc
    
    return (mat4){
        Matrix_Vector_Multiplication(A, B.x),
        Matrix_Vector_Multiplication(A, B.y),
        Matrix_Vector_Multiplication(A, B.z),
        Matrix_Vector_Multiplication(A, B.w)
    };
}

mat4 Transpose_Matrix(mat4 M){
    mat4 result;
    result.x = (vec4){ M.x.x, M.y.x, M.z.x, M.w.x }; 
    result.y = (vec4){ M.x.y, M.y.y, M.z.y, M.w.y };
    result.z = (vec4){ M.x.z, M.y.z, M.z.z, M.w.z }; 
    result.w = (vec4){ M.x.w, M.y.w, M.z.w, M.w.w }; 
    return result;
}

vec4 Matrix_Vector_Multiplication(mat4 M, vec4 v){
    return (vec4){//row by row 
        M.x.x*v.x + M.y.x*v.y + M.z.x*v.z + M.w.x*v.w,
        M.x.y*v.x + M.y.y*v.y + M.z.y*v.z + M.w.y*v.w,
        M.x.z*v.x + M.y.z*v.y + M.z.z*v.z + M.w.z*v.w,
        M.x.w*v.x + M.y.w*v.y + M.z.w*v.z + M.w.w*v.w
    };
}

//return 1 is good, 0 if not
int Matrix_Inverse(mat4 M, mat4* out){//using Gauss-Jordan elimination
    float a[4][8] = {//buuild the augmented matrix [M|I]
        { M.x.x, M.y.x, M.z.x, M.w.x, 1,0,0,0 },//diagnol 1/0
        { M.x.y, M.y.y, M.z.y, M.w.y, 0,1,0,0 },
        { M.x.z, M.y.z, M.z.z, M.w.z, 0,0,1,0 },
        { M.x.w, M.y.w, M.z.w, M.w.w, 0,0,0,1 }
    };

    for (int c=0; c<4; ++c){//make pivot per c
        int pivot=c;
        for (int r=c+1; r<4; ++r)//choose pivot row
        if (fabsf(a[r][c]) > fabsf(a[pivot][c])) pivot=r;
        if (fabsf(a[pivot][c]) < 1e-8f) return 0;         

        if (pivot!=c) for (int j=0;j<8;++j){ float t=a[c][j]; a[c][j]=a[pivot][j]; a[pivot][j]=t; }//swap p row into place

        float invp = 1.0f / a[c][c];
        for (int j=0;j<8;++j) a[c][j] *= invp;//normalize pivot row so pivot = 1

        for (int r=0; r<4; ++r) if (r!=c){//eliminate pivot row from other rows
            float f = a[r][c];
            if (f!=0.0f) for (int j=0;j<8;++j) a[r][j] -= f * a[c][j];
        }
    }
    //extract the inverse from the right half
    out->x.x=a[0][4]; out->y.x=a[0][5]; out->z.x=a[0][6]; out->w.x=a[0][7];
    out->x.y=a[1][4]; out->y.y=a[1][5]; out->z.y=a[1][6]; out->w.y=a[1][7];
    out->x.z=a[2][4]; out->y.z=a[2][5]; out->z.z=a[2][6]; out->w.z=a[2][7];
    out->x.w=a[3][4]; out->y.w=a[3][5]; out->z.w=a[3][6]; out->w.w=a[3][7];
    return 1;
}


