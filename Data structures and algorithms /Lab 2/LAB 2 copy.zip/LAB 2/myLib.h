/*myLib.h fully impleneted by Ryan Farrar for class 1566*/
#ifndef _MYLIB_H_

#define _MYLIB_H_

typedef struct {
    float x;
    float y;
    float z;
    float w;
} vec4;

typedef struct {
    vec4 x;
    vec4 y;
    vec4 z;
    vec4 w;
} mat4;

// function signiatures
//--- VECTOR FUNCTIONS
void print_v4(vec4);
vec4 Scalar_Vector_Multiplication(vec4 V, float S);
vec4 Vector_Vector_Addition(vec4 A, vec4 B);
vec4 Vector_Vector_Subtraction(vec4 A, vec4 B);
float Magnitude_Of_Vector(vec4 V);
vec4 Normalize_Vector(vec4 V);
float Dot_Product(vec4 A, vec4 B);
vec4 Cross_Product(vec4 A, vec4 B);

//--- MATRIX FUNCTIONS
void print_mat4(mat4 v);
mat4 Scalar_Matrix_Multiplication(mat4 M, float S);
mat4 Matrix_Matrix_Addition(mat4 A, mat4 B);
mat4 Matrix_Matrix_Subtraction(mat4 A, mat4 B);
mat4 Matrix_Matrix_Multiplication(mat4 A, mat4 B);
mat4 Transpose_Matrix(mat4 M);
vec4 Matrix_Vector_Multiplication(mat4 M, vec4 v);
int Matrix_Inverse(mat4 M, mat4* out);  // 1 if successful, 0 if not, u



// Do not put anything after this line

#endif
